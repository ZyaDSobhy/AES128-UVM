# Advanced-Encryption-Standard-AES-
Verilog Implementation of 128 Key AES

4 minutes video illustrates the standard

https://youtu.be/gP4PqVGudtg

