/*	Conor Nolan 6/03/2018	*/

#include "FunctionHeaders.h"

int main()
{
	run_AES();
	return 0;
}